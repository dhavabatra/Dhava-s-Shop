<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use app\Models\Barang;

class BarangController extends Controller
{
    public function index(){
        $produk = DB::table('barangs')->get();
        return view('produk/body/produk', ['produk' => $produk]);
    }

    public function review($id){
        $produk = DB::select('barangs')->find($id);
        return view('produk/body/review', ['produk' => $produk]);
    }
}
