<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use app\Models\Barang;

class BarangSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('Barangs')->insert([
            'nama'  => 'Jam Tangan',
            'desc'  => 'Jam tangan kualitas tinggi, dapat melewati dimensi ruang dan waktu',
            'harga' => '2450000',
            'gambar'=> 'jam_tangan.jpg'
        ]);
    }
}
