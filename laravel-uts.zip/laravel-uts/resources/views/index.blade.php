@extends('produk.master')

@section('title', 'Home')

@section('content')
    body
@endsection