@extends('produk.master')

@section('title', 'Tentang Saya')

@section('content')
    tentang saya
@endsection