<nav class="border-bottom">
    <div class="container my-2">
        <nav class="navbar navbar-expand-lg">
            <div class="container-fluid">
                <a id="brand" class="navbar-brand me-5" href="/"><strong>Dhava's Shop</strong></a>
                <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                    <div class="navbar-nav">
                        <a class="nav-link active mx-4" aria-current="page" href="produk">Produk</a>
                        <a class="nav-link active" aria-current="page" href="about">Tentang Saya</a>
                    </div>
                </div>
            </div>
        </nav>
    </div>
</nav>
