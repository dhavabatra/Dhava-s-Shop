@extends('produk.master')

@section('title', 'Produk')

@section('content')
    <div id="text-semua" class="border-bottom">
        <h1>Explore Produk</h1>
    </div>


    <div class="container ">
        <div class="row row-cols-1 row-cols-md-4 g-4">
            @foreach ($produk as $data)
                <a href="review/{{ $data->id }}" class="text-decoration-none">
                    <div class="col">
                        <div class="card h-100">
                            <img src="{{asset('image/'. $data->gambar)}}" id="gambar-produk" class="card-img-top" alt="...">
                            <div class="card-body">
                                <p class="card-title">{{ $data->nama }}</p>
                                <p class="card-text"><strong> Rp.{{ $data->harga }}</strong></p>
                                {{-- <p class="card-text">{{ $data->desc }}</p> --}}
                            </div>
                        </div>
                    </div>
                </a>
            @endforeach
        </div>
    </div>


    {{-- <main id="body-produk" class="border-top">
        <div class="container">
            <h2 id="text-semua">Semua Produk</h2>

            <table class="table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Barang</th>
                        <th>Deskipsi</th>
                        <th>Harga</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($produk as $data)
                        <tr>
                            <td>{{ $loop->iteration }}</td>
                            <td>{{ $data->nama }}</td>
                            <td>{{ $data->desc }}</td>
                            <td>Rp.{{ $data->harga }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
            <table class="table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Barang</th>
                        <th>Deskipsi</th>
                        <th>Harga</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($produk as $data)
                        <tr>
                            <td>{{ $loop->iteration }}</td>
                            <td>{{ $data->nama }}</td>
                            <td>{{ $data->desc }}</td>
                            <td>Rp.{{ $data->harga }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
            <table class="table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Barang</th>
                        <th>Deskipsi</th>
                        <th>Harga</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($produk as $data)
                        <tr>
                            <td>{{ $loop->iteration }}</td>
                            <td>{{ $data->nama }}</td>
                            <td>{{ $data->desc }}</td>
                            <td>Rp.{{ $data->harga }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </main> --}}


@endsection
