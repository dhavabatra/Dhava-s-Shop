@extends('produk.master')

@section('title', 'review')

@section('content')
    <div class="container">
        @foreach ($produk as $data)
            <div class="review">
                <<img src="{{ asset('image/' . $data->gambar) }}" class="card-img-top" alt="...">
                    <div class="detail">
                        <p class="card-title">{{ $data->nama }}</p>
                        <p class="card-text"><strong> Rp.{{ $data->harga }}</strong></p>
                        <p class="card-text">{{ $data->desc }}</p>
                    </div>
            </div>
        @endforeach
    </div>
@endsection
