<?php

use Illuminate\Support\Facades\Route;
use app\Http\Controllers\BarangController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

Route::view('/', 'index');

Route::get('/produk', 'BarangController@index');
Route::get('/review/{id}', 'BarangController@review');

Route::view('/about', 'produk/body/about');

// Route::prefix('produk')->group(function () {
//     Route::get('/list-barang/{id}', function($id){
//         return view('list-barang', ['id' => $id]);
//     }); 
// });