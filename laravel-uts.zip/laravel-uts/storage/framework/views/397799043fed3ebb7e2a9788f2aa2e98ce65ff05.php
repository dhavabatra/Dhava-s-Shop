

<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
    body
<?php $__env->stopSection(); ?>
<?php echo $__env->make('produk.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\laravel-uts\resources\views/index.blade.php ENDPATH**/ ?>