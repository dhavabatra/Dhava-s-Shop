<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Produk</title>
</head>
<body>
    <h1>List Barang</h1>
    <h3>Barang ke <?php echo e($id); ?></h3>
</body>
</html><?php /**PATH D:\XAMPP\htdocs\laravel-uts\resources\views/produk/list-barang.blade.php ENDPATH**/ ?>