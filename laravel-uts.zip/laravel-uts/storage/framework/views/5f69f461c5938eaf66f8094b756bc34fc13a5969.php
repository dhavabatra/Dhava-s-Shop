

<?php $__env->startSection('title', 'Tentang Saya'); ?>

<?php $__env->startSection('content'); ?>
    tetang sayang
<?php $__env->stopSection(); ?>
<?php echo $__env->make('produk.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\laravel-uts\resources\views/produk/body/about.blade.php ENDPATH**/ ?>