

<?php $__env->startSection('title', 'Produk'); ?>

<?php $__env->startSection('content'); ?>
    <div id="text-semua" class="border-bottom">
        <h1>Explore Produk</h1>
    </div>


    <div class="container ">
        <div class="row row-cols-1 row-cols-md-4 g-4">
            <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="review/<?php echo e($data->id); ?>" class="text-decoration-none">
                    <div class="col">
                        <div class="card h-100">
                            <img src="<?php echo e(asset('image/'. $data->gambar)); ?>" id="gambar-produk" class="card-img-top" alt="...">
                            <div class="card-body">
                                <p class="card-title"><?php echo e($data->nama); ?></p>
                                <p class="card-text"><strong> Rp.<?php echo e($data->harga); ?></strong></p>
                                
                            </div>
                        </div>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>


    


<?php $__env->stopSection(); ?>

<?php echo $__env->make('produk.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\laravel-uts\resources\views/produk/body/produk.blade.php ENDPATH**/ ?>