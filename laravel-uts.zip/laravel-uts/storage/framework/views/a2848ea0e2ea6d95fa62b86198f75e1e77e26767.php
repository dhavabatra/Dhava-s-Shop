<!-- Remove the container if you want to extend the Footer to full width. -->
<div class=" my-5">

    <footer class="text-center text-lg-start" style="background-color: #646464;">
      <div class="container d-flex justify-content-center py-5">
        <button type="button" class="btn btn-primary btn-lg btn-floating mx-2" style="background-color: #54456b;">
        </button>
        <button type="button" class="btn btn-primary btn-lg btn-floating mx-2" style="background-color: #54456b;">
        </button>
        <button type="button" class="btn btn-primary btn-lg btn-floating mx-2" style="background-color: #54456b;">
        </button>
        <button type="button" class="btn btn-primary btn-lg btn-floating mx-2" style="background-color: #54456b;">
        </button>
      </div>
  
      <!-- Copyright -->
      <div class="text-center text-white p-3" style="background-color: rgba(0, 0, 0, 0.2);">
        © 2022 Copyright:
        <a class="text-white" href="#">Dhava Batra</a>
      </div>
      <!-- Copyright -->
    </footer>
    
  </div>
  <!-- End of .container --><?php /**PATH D:\XAMPP\htdocs\laravel-uts\resources\views/produk/body/footer.blade.php ENDPATH**/ ?>