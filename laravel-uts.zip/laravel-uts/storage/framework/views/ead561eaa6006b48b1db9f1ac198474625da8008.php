

<?php $__env->startSection('title', 'review'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="review">
                <<img src="<?php echo e(asset('image/' . $data->gambar)); ?>" class="card-img-top" alt="...">
                    <div class="detail">
                        <p class="card-title"><?php echo e($data->nama); ?></p>
                        <p class="card-text"><strong> Rp.<?php echo e($data->harga); ?></strong></p>
                        <p class="card-text"><?php echo e($data->desc); ?></p>
                    </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('produk.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\XAMPP\htdocs\laravel-uts\resources\views/produk/body/review.blade.php ENDPATH**/ ?>